# Matterhorn Desks Release Candidate Manifest

**Decision:** REVIEWABLE
**Branch:** ``
**HEAD:** `4a6bfe3a1780a96fd2f1456916753818cd3d34d8`
**Candidate source digest:** `4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945`

- Candidate-review paths: 0
- Preserve-only paths: 3
- Staged candidate paths: 0
- Staged protected paths: 0
- Unclassified paths: 0

Preserve-only filenames are intentionally omitted. Only root-level counts are recorded.

## Buckets

| Bucket | Paths |
|---|---:|
| Tests and release documentation | 0 |
| Release engineering | 0 |
| Public web and security | 0 |
| Wallet and market safety | 0 |
| Runtime and recovery | 0 |
| UI and accessibility | 0 |
| Branding and product truth | 0 |
| Unclassified | 0 |

